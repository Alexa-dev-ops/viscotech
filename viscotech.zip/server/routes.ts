import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { orderStatus } from "@shared/schema";

export function registerRoutes(app: Express): Server {
  setupAuth(app);

  // Products routes
  app.get("/api/products", async (_req, res) => {
    const products = await storage.getAllProducts();
    res.json(products);
  });

  app.get("/api/products/category/:category", async (req, res) => {
    const products = await storage.getProductsByCategory(req.params.category);
    res.json(products);
  });

  app.get("/api/products/:id", async (req, res) => {
    const product = await storage.getProduct(parseInt(req.params.id));
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }
    res.json(product);
  });

  // Enhanced Orders routes
  app.post("/api/orders", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const order = await storage.createOrder({
      userId: req.user.id,
      items: req.body.items,
      total: req.body.total,
      status: orderStatus.PENDING,
      createdAt: new Date(),
      updatedAt: new Date(),
    });

    res.status(201).json(order);
  });

  app.get("/api/orders", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const orders = await storage.getOrdersByUser(req.user.id);
    res.json(orders);
  });

  app.get("/api/orders/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const order = await storage.getOrder(parseInt(req.params.id));
    if (!order) {
      return res.status(404).json({ message: "Order not found" });
    }

    if (order.userId !== req.user.id) {
      return res.status(403).json({ message: "Forbidden" });
    }

    res.json(order);
  });

  app.patch("/api/orders/:id/status", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const newStatus = req.body.status;
    if (!Object.values(orderStatus).includes(newStatus)) {
      return res.status(400).json({ message: "Invalid status" });
    }

    const order = await storage.getOrder(parseInt(req.params.id));
    if (!order) {
      return res.status(404).json({ message: "Order not found" });
    }

    if (order.userId !== req.user.id) {
      return res.status(403).json({ message: "Forbidden" });
    }

    const updatedOrder = await storage.updateOrderStatus(order.id, newStatus);
    res.json(updatedOrder);
  });

  const httpServer = createServer(app);
  return httpServer;
}
interface PaystackConfig {
  email: string;
  amount: number;
  publicKey: string;
  onSuccess: () => void;
  onCancel: () => void;
}

export function usePaystackPayment() {
  const initializePayment = (config: PaystackConfig) => {
    const handler = window.PaystackPop.setup({
      key: config.publicKey,
      email: config.email,
      amount: config.amount,
      currency: 'NGN',
      callback: () => {
        config.onSuccess();
      },
      onClose: () => {
        config.onCancel();
      },
    });
    handler.openIframe();
  };

  return { initializePayment };
}

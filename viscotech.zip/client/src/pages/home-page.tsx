import { useQuery } from "@tanstack/react-query";
import NavBar from "@/components/nav-bar";
import ProductGrid from "@/components/product-grid";
import SearchBar from "@/components/search-bar";
import { Product } from "@shared/schema";
import { useState } from "react";

export default function HomePage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const { data: products = [], isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const filteredProducts = products.filter((product) => {
    const matchesSearch = product.name
      .toLowerCase()
      .includes(searchTerm.toLowerCase());
    const matchesCategory = !selectedCategory || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const categories = Array.from(
    new Set(products.map((product) => product.category))
  );

  return (
    <div className="min-h-screen bg-background">
      <NavBar />
      
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
            Welcome to Visco Tech
          </h1>
          <p className="text-muted-foreground max-w-2xl">
            Discover the latest in technology and innovation. From premium audio gear
            to cutting-edge computing solutions, find everything you need for your
            tech lifestyle.
          </p>
        </div>

        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <SearchBar value={searchTerm} onChange={setSearchTerm} />
          <select
            className="p-2 border rounded-md"
            value={selectedCategory || ""}
            onChange={(e) => setSelectedCategory(e.target.value || null)}
          >
            <option value="">All Categories</option>
            {categories.map((category) => (
              <option key={category} value={category}>
                {category}
              </option>
            ))}
          </select>
        </div>

        <ProductGrid products={filteredProducts} isLoading={isLoading} />
      </main>
    </div>
  );
}

import { Product } from "@shared/schema";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useCart } from "@/hooks/use-cart";
import { Check, ShoppingCart, Trash2 } from "lucide-react";

export default function ProductCard({ product }: { product: Product }) {
  const { addItem, removeItem, items } = useCart();
  const isInCart = items.some(item => item.product.id === product.id);

  const handleCartAction = () => {
    if (isInCart) {
      removeItem(product.id);
    } else {
      addItem(product);
    }
  };

  const formatPrice = (price: string) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 2
    }).format(Number(price));
  };

  return (
    <Card className="overflow-hidden">
      <img
        src={product.image}
        alt={product.name}
        className="h-48 w-full object-cover"
      />
      <CardContent className="p-4">
        <h3 className="font-semibold truncate">{product.name}</h3>
        <p className="text-muted-foreground text-sm line-clamp-2 h-10">
          {product.description}
        </p>
        <div className="mt-2 font-semibold">{formatPrice(product.price)}</div>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <Button
          className="w-full"
          onClick={handleCartAction}
          variant={isInCart ? "destructive" : "default"}
        >
          {isInCart ? (
            <span className="flex items-center">
              <Trash2 className="w-4 h-4 mr-2" />
              Remove from Cart
            </span>
          ) : (
            <span className="flex items-center">
              <ShoppingCart className="w-4 h-4 mr-2" />
              Add to Cart
            </span>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ShoppingCart, User, Package } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useCart } from "@/hooks/use-cart";
import CartDrawer from "./cart-drawer";
import { useState } from "react";

export default function NavBar() {
  const { user, logoutMutation } = useAuth();
  const { items } = useCart();
  const [isCartOpen, setIsCartOpen] = useState(false);

  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/">
          <a className="text-2xl font-bold bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
            Visco Tech
          </a>
        </Link>

        <div className="flex items-center gap-4">
          {user ? (
            <>
              <div className="text-sm text-muted-foreground">
                Welcome, {user.username}
              </div>
              <Link href="/orders">
                <Button variant="outline">
                  <Package className="h-4 w-4 mr-2" />
                  Orders
                </Button>
              </Link>
              <Button
                variant="outline"
                onClick={() => logoutMutation.mutate()}
                disabled={logoutMutation.isPending}
              >
                Logout
              </Button>
            </>
          ) : (
            <Link href="/auth">
              <Button variant="outline">
                <User className="h-4 w-4 mr-2" />
                Login
              </Button>
            </Link>
          )}

          <Button
            variant="outline"
            className="relative"
            onClick={() => setIsCartOpen(true)}
          >
            <ShoppingCart className="h-4 w-4" />
            {totalItems > 0 && (
              <span className="absolute -top-2 -right-2 bg-primary text-primary-foreground rounded-full w-5 h-5 text-xs flex items-center justify-center">
                {totalItems}
              </span>
            )}
          </Button>
        </div>

        <CartDrawer open={isCartOpen} onClose={() => setIsCartOpen(false)} />
      </div>
    </nav>
  );
}
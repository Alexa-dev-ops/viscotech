import { pgTable, text, serial, integer, decimal, json, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  image: text("image").notNull(),
  category: text("category").notNull(),
});

export const orderStatus = {
  PENDING: "pending",
  PROCESSING: "processing",
  SHIPPED: "shipped",
  DELIVERED: "delivered",
  CANCELLED: "cancelled",
} as const;

export type OrderStatus = typeof orderStatus[keyof typeof orderStatus];

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  items: json("items").$type<Array<{productId: number, quantity: number}>>().notNull(),
  total: decimal("total", { precision: 10, scale: 2 }).notNull(),
  status: text("status").notNull().$type<OrderStatus>().default(orderStatus.PENDING),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertProductSchema = createInsertSchema(products);
export const insertOrderSchema = createInsertSchema(orders);

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Product = typeof products.$inferSelect;
export type Order = typeof orders.$inferSelect;

export const mockProducts: Product[] = [
  {
    id: 1,
    name: "Premium Wireless Headphones",
    description: "High-quality wireless headphones with noise cancellation",
    price: "149995.00",
    image: "https://images.unsplash.com/photo-1484704849700-f032a568e944",
    category: "Audio",
  },
  {
    id: 2,
    name: "Ultra HD Smart Watch",
    description: "Advanced smartwatch with health monitoring features",
    price: "99995.00",
    image: "https://images.unsplash.com/photo-1524656855800-59465ebcec69",
    category: "Wearables",
  },
  {
    id: 3,
    name: "Professional Camera Kit",
    description: "Complete camera kit for professional photography",
    price: "649995.00",
    image: "https://images.unsplash.com/photo-1502096472573-eaac515392c6",
    category: "Photography",
  },
  {
    id: 4,
    name: "Gaming Laptop Pro",
    description: "High-performance gaming laptop with RGB keyboard",
    price: "999995.00",
    image: "https://images.unsplash.com/photo-1486475554424-2fa50cd59f18",
    category: "Computers",
  },
  {
    id: 5,
    name: "Wireless Gaming Mouse",
    description: "Precision gaming mouse with customizable buttons",
    price: "39995.00",
    image: "https://images.unsplash.com/photo-1498887983185-44bfeb64b956",
    category: "Accessories",
  },
  {
    id: 6,
    name: "4K Gaming Monitor",
    description: "Ultra-wide 4K gaming monitor with HDR",
    price: "349995.00",
    image: "https://images.unsplash.com/photo-1515849430397-7aee921bbea1",
    category: "Monitors",
  }
];